#import "../../lib.typ": *

= 基本功能介绍 <introduction>

欢迎使用基于#link("https://typst.app")[Typst]的同济大学本科生毕业设计论文模板！

Typst是被广泛认为是#LaTeX 的 “进化版”，它保留了#LaTeX 的强大功能和灵活性，同时由于其编译时间短、易于上手等特点，也被认为是#LaTeX 的
“所见即所得（WYSIWYG，What You See Is What You Get）” 的实现。
Typst的设计理念是让文档的制作过程更加高效和愉快，同时保持专业级的输出质量。然而，由于Typst仍处于开发阶段，它的功能远没有#LaTeX 和基于#LaTeX 的C#TeX 那么丰富，因此在使用Typst时，我们可能需要一些额外的工作来完成一些特殊的排版需求。

在本章（@introduction）中，我们将介绍 Typst
的简单使用方法，尤其是中文排版的相关内容，并提供一些常用的排版示例。如果你对
Typst 的使用方法还不太熟悉，可以参考#link("https://typst.app/docs")[#emph[Typst的官方文档]]。

== 标题

Typst 用 `=` 来表示标题，其后紧跟标题内容。标题的级别由 `=` 的个数决定，`=` 的个数越多，标题级别越低。本模板支持的标题级别最高为
5，即
`=====`。

除了 `=`，Typst 还支持使用 #raw("#heading()", lang: "typ") 函数来表示标题，还可以自定义标题的样式。

下面是一个标题的例子：

#table(
  columns: (1fr, 1fr), [
    #set align(center)
    #strong[代码]
  ], [
    #set align(center)
    #strong[渲染结果]
  ], ```typ
      #heading(level: 2, outlined: false, "二级标题")

      二级标题是一种较为重要的标题级别，一般用于表示文章中的主要章节或主题。通常，它们会在上面添加分割线或加粗等效果，以突出其重要性。

      #heading(level: 3, outlined: false, "三级标题")

      相对于二级标题而言，三级标题是更加具体的标题级别，通常用于表示二级标题下的具体内容描述。它们的长度通常比二级标题短，与二级标题之间应有一定的间距。

      #heading(level: 4, outlined: false, "段落标题")

      段落标题是文章中比正文稍微具有一些重要性和突出性的内容，通常用加粗或斜体等方式来区别于正文。

      #heading(level: 5, outlined: false, "子段落标题")

      子段落标题是相对于段落标题更加细节化的内容，用于突出一段文字中的重点内容。通常采用斜体或加粗的方式表示。在一些正式的文献中，子段落标题的使用较少。
        ```, [
    #h(2em)
    #heading(level: 2, outlined: false, "二级标题")

    二级标题是一种较为重要的标题级别，一般用于表示文章中的主要章节或主题。通常，它们会在上面添加分割线或加粗等效果，以突出其重要性。

    #heading(level: 3, outlined: false, "三级标题")

    相对于二级标题而言，三级标题是更加具体的标题级别，通常用于表示二级标题下的具体内容描述。它们的长度通常比二级标题短，与二级标题之间应有一定的间距。

    #heading(level: 4, outlined: false, "段落标题")

    段落标题是文章中比正文稍微具有一些重要性和突出性的内容，通常用加粗或斜体等方式来区别于正文。

    #heading(level: 5, outlined: false, "子段落标题")

    子段落标题是相对于段落标题更加细节化的内容，用于突出一段文字中的重点内容。通常采用斜体或加粗的方式表示。在一些正式的文献中，子段落标题的使用较少。
  ],
)

// 上表中的示例标题占用了标题编号，这里恢复，使下一节仍为 1.2
#counter(heading).update((1, 1))

值得注意的是，本模板中的标题样式已经根据同济大学的毕业论文要求进行了调整，因而可能与
Typst 的默认样式有所不同。

== 字体

与Markdown类似，在Typst中，粗体文字用 `*` 包裹，斜体文字用 `_` 包裹，等宽字体用 #raw("`") 包裹。例如：

#table(columns: (1fr, 1fr), [
  #set align(center)
  #strong[代码]
], [
  #set align(center)
  #strong[渲染结果]
], ```typ
In Typst, *bold*, _italic_ and `monospace` are supported.
  ```, [
In Typst, *bold*, _italic_ and `monospace` are supported.
])

在本模板中，中文的粗体为加粗的宋体（字体没有粗体字形时，按 Word 的方式以字号 1/35 的描边模拟加粗，与 LaTeX 模板相同），斜体为 “#emph[楷体]”，等宽字体中的汉字为 “#raw("仿宋")”。

请注意，因为语法解析的限制， `*...*`、`_..._` 和 #raw("`...`") 的前后有时需要空格分隔；而由于中文字体的特殊性，这样会导致额外的空格出现。因此，为了避免这种情况，我们可以使用 #raw("#emph[...]", lang: "typ") 函数来表示斜体，#raw("#strong[...]", lang: "typ") 函数来表示加粗，#raw("#raw(\"...\")", lang: "typ") 函数来表示等宽字体。例如：

#table(
  columns: (1fr, 1fr), [
    #set align(center)
    #strong[代码]
  ], [
    #set align(center)
    #strong[渲染结果]
  ], ```typ
      在中文环境中， *粗体*、_斜体_ 和 `等宽字体` 可能会导致额外的空格出现。而#strong[粗体]、#emph[斜体]和#raw("等宽字体")则不会。
        ```, [
  在中文环境中， *粗体*、_斜体_ 和 `等宽字体` 可能会导致额外的空格出现。而#strong[粗体]、#emph[斜体]和#raw("等宽字体")则不会。
  ],
)

字体由 `main.typ` 中的 `fontset` 选项选择，与 LaTeX 模板的同名选项对应。默认值 `"auto"` 在系统装有 Word 模板所用的中易字体（SimSun 等）时选用 `windows`，否则选用 `texlive`，即 LaTeX 模板 `fontset=texlive` 使用的免费字体（霞鹜新致宋、霞鹜新晰黑、文鼎 PL 中楷、朱雀仿宋）。也可直接指定 `windows`、`texlive`、`founder`、`adobe`、`mac` 或 `fandol`。四种字体可分别用以下命令调用：

#table(
  columns: (auto, auto, 1fr), [
    #set align(center)
    #strong[字体]
  ], [
    #set align(center)
    #strong[命令]
  ], [
    #set align(center)
    #strong[渲染结果]
  ], [
    #set align(center)
    #songti[宋体]
  ], [
    #set align(center)
    #raw("#songti[...]", lang: "typ")
  ], [
    #songti[#h(2em)1900年前后，由埃里希 · 宝隆创办的 “同济医院” 正式挂牌。埃里希 ·
    宝隆医生看到医院里的医疗力量不足，计划在院内设立德文医学堂，招收中国学生，培养施诊医生。]
  ], [
    #set align(center)
    #heiti[黑体]
  ], [
    #set align(center)
    #raw("#heiti[...]", lang: "typ")
  ], [
    #heiti[#h(2em)这个计划得到德国驻沪总领事以及德国政府高等教育司的支持。1906年，他们设立了一个支持医学堂开办的基金会，得到了德国
    “促进德国与外国思想交流的科佩尔基金会”
    的协助，筹集到一批医科书刊及新式的外科手术电动器械等物品。]
  ], [
    #set align(center)
    #kaiti[楷体]
  ], [
    #set align(center)
    #raw("#kaiti[...]", lang: "typ")
  ], [
    #kaiti[#h(2em)1907年6月医学堂开学前，德国驻沪总领事克纳佩在上海不仅号召德国商人捐款，而且要求德国洋行向中国商人募捐。同时，费舍尔还要求中国官方的资助和支持，克纳佩利用在中德两国募来的捐款，成立了
    “为中国人办的德国医学堂基金会”。]
  ], [
    #set align(center)
    #fangsong[仿宋]
  ], [
    #set align(center)
    #raw("#fangsong[...]", lang: "typ")
  ], [
    #fangsong[#h(2em)董事会由18人组成，主要成员有：三个德医公会元老：宝隆、福沙伯（第二任校长）、福尔克尔；三名德国商人：莱姆克、米歇劳和赖纳；两名中国绅商：朱葆三（沪军都督府财政部长及上海商务会会长，大买办）、虞洽卿（荷兰银行买办）；总领事馆的副领事弗赖海尔
    · 冯 · 吕特等。]
  ],
)

我们还可以使用 #raw("#underline[]", lang: "typ") 命令来表示下划线，例如：

#table(columns: (1fr, 1fr), [
  #set align(center)
  #strong[代码]
], [
  #set align(center)
  #strong[渲染结果]
], ```typ
#underline[中Lorem文ipsum中dolor文]
  ```, [
  #underline[中Lorem文ipsum中dolor文]
])

== 列表

列表是论文中常用的排版元素，本节展示无序列表和有序列表的使用方法。有序列表的编号格式已按照同济大学毕业设计（论文）撰写规范进行配置。

=== 无序列表

无序列表适用于列举不需要特定顺序的内容，使用 `-` 创建：

#table(columns: (1fr, 1fr), [
  #set align(center)
  #strong[代码]
], [
  #set align(center)
  #strong[渲染结果]
], ```typ
- 同济大学是中国著名的高等学府之一，拥有悠久的历史和丰富的文化底蕴。
- 校园位于上海市，这里是中国经济和文化的重要中心。
- 以工科著称，培养了大批优秀的工程技术人才。
  ```, [
  - 同济大学是中国著名的高等学府之一，拥有悠久的历史和丰富的文化底蕴。
  - 校园位于上海市，这里是中国经济和文化的重要中心。
  - 以工科著称，培养了大批优秀的工程技术人才。
])

=== 有序列表

有序列表适用于列举需要按顺序排列的内容，使用 `+` 创建。第一级编号使用全角圆括号数字“（1）”“（2）”等，第二级编号使用圆圈数字“①”“②”等。

#table(columns: (1fr, 1fr), [
  #set align(center)
  #strong[代码]
], [
  #set align(center)
  #strong[渲染结果]
], ```typ
+ 同济大学历史：
  + 1907年：创建，最初为德文医学堂
  + 1927年：成为国立大学，更名为同济大学
  + 1952年：以工科为主
+ 学术体系：
  + 工程学，包括土木工程、建筑工程、机械工程等
  + 建筑学，包括建筑设计、城市规划等
  + 医学，包括临床医学、药学等
+ 国际合作：
  + 德国交流项目
  + 全球合作伙伴
  + 国际学术会议
  ```, [
  + 同济大学历史：
    + 1907年：创建，最初为德文医学堂
    + 1927年：成为国立大学，更名为同济大学
    + 1952年：以工科为主
  + 学术体系：
    + 工程学，包括土木工程、建筑工程、机械工程等
    + 建筑学，包括建筑设计、城市规划等
    + 医学，包括临床医学、药学等
  + 国际合作：
    + 德国交流项目
    + 全球合作伙伴
    + 国际学术会议
])
