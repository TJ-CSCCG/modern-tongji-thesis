// ============================================================
//  中文摘要
// ============================================================
#let abstract = [
  摘要通常是一篇文章、论文、报告或其他文本的简短概括。它的目的是帮助读者了解文本的主要内容和结论，以便决定是否需要继续阅读原文。摘要通常包含文本的主题、目的、方法、结果和结论等方面的信息，并尽可能简洁明了地呈现。好的摘要应该能够概括文本的重点，同时避免使用不必要的细节和专业术语，以便广大读者能够轻松理解。

  此外，摘要通常也是学术界和研究人员评估一篇文献的重要依据之一。在文献检索和筛选过程中，人们通常会根据摘要来决定是否进一步查看完整的文献。因此，撰写一个清晰、准确、简洁的摘要对于文献的传播和影响力至关重要。在撰写摘要时，作者应该遵循文献的格式要求和撰写规范，同时结合文本的内容和目的，将摘要撰写得准确、简洁、易懂，以提高文献的传播和影响力。
]

#let keywords = ("关键词1", "关键词2", "关键词3")

// ============================================================
//  英文摘要
// ============================================================
#let abstract-english = [
  An abstract is usually a short summary of an article, essay, report, or other
  text. Its purpose is to help the reader understand the main content and
  conclusions of the text so that he or she can decide whether he or she needs to
  continue reading the original text. The abstract usually contains information
  about the topic, purpose, methods, results, and conclusions of the text and is
  presented as concisely and clearly as possible. A good abstract should be able
  to summarize the main points of the text while avoiding unnecessary details and
  jargon so that it can be easily understood by a wide audience.

  In addition, abstracts are often one of the most important bases on which
  academics and researchers evaluate a piece of literature. During the literature
  search and selection process, people often base their decision to look further
  into the complete literature on the abstract. Therefore, writing a clear,
  accurate, and concise abstract is crucial to the dissemination and impact of the
  literature. When writing an abstract, authors should follow the formatting
  requirements and writing specifications of the literature, as well as combine
  the content and purpose of the text to write an accurate, concise, and
  easy-to-understand abstract in order to improve the dissemination and impact of
  the literature.
]

#let keywords-english = ("Keyword 1", "Keyword 2", "Keyword 3")
